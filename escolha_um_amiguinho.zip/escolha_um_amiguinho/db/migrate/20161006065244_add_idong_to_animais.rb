class AddIdongToAnimais < ActiveRecord::Migration
  def change
    add_reference :animais, :idong, index: true, foreign_key: true
  end
end
