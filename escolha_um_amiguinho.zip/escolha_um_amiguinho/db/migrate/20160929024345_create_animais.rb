class CreateAnimais < ActiveRecord::Migration
  def change
    create_table :animais do |t|
      t.string :nome
      t.string :sexo
      t.string :porte
      t.string :peso
      t.string :idade
      t.string :tipo
      t.string :status
      t.references :ONG

      t.timestamps null: false
    end
  end
end
