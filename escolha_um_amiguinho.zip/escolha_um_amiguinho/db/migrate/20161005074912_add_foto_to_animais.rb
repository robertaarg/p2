class AddFotoToAnimais < ActiveRecord::Migration
  def change
    add_column :animais, :foto, :string
  end
end
