class AddAchadoEmToAnimais < ActiveRecord::Migration
  def change
    add_column :animais, :AchadoEm, :date
  end
end
