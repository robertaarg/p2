class AddOngToAnimais < ActiveRecord::Migration
  def change
    add_reference :animais, :ONG, index: true, foreign_key: true
  end
end
  