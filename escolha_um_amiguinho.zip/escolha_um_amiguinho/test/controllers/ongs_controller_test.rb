require 'test_helper'

class OngsControllerTest < ActionController::TestCase
  setup do
    @ong = ongs(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:ongs)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create ong" do
    assert_difference('Ong.count') do
      post :create, ong: { cidade: @ong.cidade, cnpj: @ong.cnpj, email: @ong.email, estado: @ong.estado, nome: @ong.nome, senha: @ong.senha, telefone: @ong.telefone, usuario: @ong.usuario }
    end

    assert_redirected_to ong_path(assigns(:ong))
  end

  test "should show ong" do
    get :show, id: @ong
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @ong
    assert_response :success
  end

  test "should update ong" do
    patch :update, id: @ong, ong: { cidade: @ong.cidade, cnpj: @ong.cnpj, email: @ong.email, estado: @ong.estado, nome: @ong.nome, senha: @ong.senha, telefone: @ong.telefone, usuario: @ong.usuario }
    assert_redirected_to ong_path(assigns(:ong))
  end

  test "should destroy ong" do
    assert_difference('Ong.count', -1) do
      delete :destroy, id: @ong
    end

    assert_redirected_to ongs_path
  end
end
