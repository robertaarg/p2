require 'test_helper'

class PaginasControllerTest < ActionController::TestCase
  test "should get login" do
    get :login
    assert_response :success
  end

  test "should get home" do
    get :home
    assert_response :success
  end

  test "should get cadastro_pessoas" do
    get :cadastro_pessoas
    assert_response :success
  end

  test "should get cadastro_ongs" do
    get :cadastro_ongs
    assert_response :success
  end

end
