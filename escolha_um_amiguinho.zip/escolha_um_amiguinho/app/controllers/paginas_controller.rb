class PaginasController < ApplicationController
  def login
  end

  def home
  end

  def cadastro_pessoas
  end

  def cadastro_ongs
  end
end
