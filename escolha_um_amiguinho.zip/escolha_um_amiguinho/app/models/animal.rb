class Animal < ActiveRecord::Base

validates_presence_of :nome, message: "O nome deve ser preenchido"
validates_presence_of :sexo, message: "O sexo deve ser preenchido"
validates_presence_of :porte, message: "O porte deve ser preenchido"
validates_presence_of :peso, message: "O peso deve ser preenchido"
validates_presence_of :idade, message: "A idade deve ser preenchido"
validates_numericality_of :peso, message: "O peso deve ser numérico"
mount_uploader :foto, FotoAnimalUploader


end
